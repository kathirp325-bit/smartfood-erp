# SmartFood ERP

A GitHub-ready, mobile-responsive ERP prototype for a South Indian packaged-snacks factory.

## Features in this prototype
- Role-based demo sign-in (sales, admin, production, auditor, owner)
- Sales orders, order approval and GST invoice calculation
- Dispatch and payment recording
- Raw-material and finished-goods stock ledger
- BOM-based production run and variance tracking
- Product costing
- Dashboard, CSV exports and PDF invoice endpoint
- FastAPI backend with SQLite and a responsive HTML/CSS/JavaScript interface

## Run locally

Requires Python 3.10+.

```bash
python -m venv .venv
```

Activate the environment:

- Windows: `.venv\\Scripts\\activate`
- macOS/Linux: `source .venv/bin/activate`

Install and run:

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Open `http://127.0.0.1:8000`. API documentation is at `http://127.0.0.1:8000/docs`.

## Demo accounts

All demo accounts use password `demo123`:

| Username | Role |
|---|---|
| `salesman_a` | Sales |
| `salesman_b` | Sales |
| `admin` | Admin |
| `production` | Production |
| `auditor` | Read-only auditor |
| `owner` | Owner |

Change/remove demo credentials before any real deployment. This project is for learning and demonstration, not production use.

## Publish to GitHub

1. Sign in at https://github.com and create a new repository named `smartfood-erp`.
2. Extract this ZIP on your device.
3. Upload the **contents** of the extracted folder (including `main.py`, `static/`, `requirements.txt`, and `render.yaml`) to the repository.
4. Add a repository description and commit the files.

Do not upload `.venv`, secrets, or a live database file.

## Deploy as a live website with Render

GitHub stores the code; it does not run the FastAPI server. To publish a live website:

1. Push this project to GitHub.
2. Sign in at https://render.com.
3. Choose **New → Blueprint** and connect your `smartfood-erp` repository.
4. Render reads `render.yaml` and creates the web service and persistent disk.
5. When deployment finishes, open the `onrender.com` URL shown by Render.

The persistent disk keeps the SQLite database between restarts. The disk option may require a paid Render plan; check Render's current pricing before deploying. If you deploy without persistent storage, database changes may be lost when the service restarts or is redeployed.

## Benchmark demo assumptions

- Flour valuation uses moving weighted average: (100 kg × ₹42 + 60 kg × ₹45) / 160 kg = ₹43.125/kg.
- Actual material cost for the benchmark run: flour ₹1,725 + oil ₹1,470 + spice ₹240 + 194 pouches ₹485 + 9 cartons ₹135 = ₹4,055.
- Run overhead: labour ₹1,200 + gas/power ₹600 = ₹1,800.
- Cost per good packet = (₹4,055 + ₹1,800) / 188 = ₹31.14.
- Finished goods: 50 + 188 - 150 dispatched = 88.
- Retailer A invoice: ₹7,500 taxable + ₹187.50 CGST + ₹187.50 SGST = ₹7,875; ₹4,000 paid; outstanding ₹3,875.
- Distributor B's requested 120 packets exceed the 88 available in the benchmark, so the order is held.
- Yield variance = (188 - 200) / 200 = -6%; oil variance = (10.5 - 10) / 10 = +5%.

## Important limitations

This is an internship/demo MVP, not a fully audited commercial ERP. GST rates, GSTINs, HSN codes, invoice numbering, costing and accounting treatment are illustrative and must be reviewed by qualified professionals before real use. It does not yet implement all production-grade requirements such as hardened authentication, complete audit trails, credit notes, supplier workflows, batch/expiry/FEFO, full GSTR-1/3B filing formats, payment ageing, Tally XML, automated test coverage or backup/restore workflows.

## Project structure

```text
smartfood-erp/
├── main.py
├── requirements.txt
├── render.yaml
├── README.md
└── static/
    └── index.html
```
