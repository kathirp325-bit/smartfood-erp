from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.responses import HTMLResponse, FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional
from decimal import Decimal, ROUND_HALF_UP
import sqlite3, os, hashlib, secrets, io, csv
from datetime import datetime, date
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

DB = os.environ.get("DB_PATH", "smartfood.db")
app = FastAPI(title="SmartFood ERP", version="1.0")
app.mount("/static", StaticFiles(directory="static"), name="static")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con

def money(x):
    return int((Decimal(str(x))*100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
def rupees(p):
    return float(Decimal(p)/100)
def init():
    c=db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT);
    CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY, name TEXT, kind TEXT, state TEXT, gstin TEXT);
    CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, name TEXT, pack_g INTEGER, price_paise INTEGER, gst_rate INTEGER, hsn TEXT);
    CREATE TABLE IF NOT EXISTS materials(id INTEGER PRIMARY KEY, name TEXT, unit TEXT, rate_paise INTEGER, kind TEXT);
    CREATE TABLE IF NOT EXISTS bom(product_id INTEGER, material_id INTEGER, qty REAL, unit TEXT, batch_yield INTEGER, PRIMARY KEY(product_id,material_id));
    CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY, item_type TEXT, item_id INTEGER, qty REAL, unit TEXT, movement TEXT, source_type TEXT, source_id INTEGER, unit_cost_paise INTEGER DEFAULT 0, created_at TEXT);
    CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY, material_id INTEGER, qty REAL, unit TEXT, rate_paise INTEGER, created_at TEXT);
    CREATE TABLE IF NOT EXISTS runs(id INTEGER PRIMARY KEY, product_id INTEGER, expected_output INTEGER, actual_output INTEGER, wastage INTEGER, labour_paise INTEGER, utilities_paise INTEGER, created_at TEXT);
    CREATE TABLE IF NOT EXISTS run_lines(id INTEGER PRIMARY KEY, run_id INTEGER, material_id INTEGER, planned REAL, actual REAL, unit TEXT, rate_paise INTEGER, damaged REAL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, customer_id INTEGER, salesman_id INTEGER, status TEXT, shortage INTEGER DEFAULT 0, created_at TEXT);
    CREATE TABLE IF NOT EXISTS order_lines(id INTEGER PRIMARY KEY, order_id INTEGER, product_id INTEGER, qty INTEGER, price_paise INTEGER);
    CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY, order_id INTEGER, invoice_no TEXT UNIQUE, taxable_paise INTEGER, cgst_paise INTEGER, sgst_paise INTEGER, igst_paise INTEGER, total_paise INTEGER, status TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY, invoice_id INTEGER, amount_paise INTEGER, received_at TEXT);
    CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT, entity TEXT, entity_id INTEGER, created_at TEXT);
    """)
    if not c.execute("SELECT 1 FROM users LIMIT 1").fetchone():
        users=[("salesman_a","salesman"),("salesman_b","salesman"),("admin","admin"),("production","production"),("auditor","auditor"),("owner","owner")]
        for u,r in users: c.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",(u,hashlib.sha256(b"demo123").hexdigest(),r))
        c.execute("INSERT INTO customers VALUES(1,'Retailer A','retailer','Tamil Nadu','33AAAAA0000A1Z5')")
        c.execute("INSERT INTO customers VALUES(2,'Distributor B','distributor','Karnataka','29BBBBB0000B1Z4')")
        c.execute("INSERT INTO products VALUES(1,'Murukku 200 g',200,5000,5,'1905')")
        mats=[("Flour","kg",4200,"raw"),("Cooking oil","litre",14000,"raw"),("Salt and spice mix","kg",20000,"raw"),("200 g pouch","piece",250,"packaging"),("Carton (20 packets)","piece",1500,"packaging")]
        for m in mats: c.execute("INSERT INTO materials(name,unit,rate_paise,kind) VALUES(?,?,?,?)",m)
        bom=[(1,1,40,"kg",200),(1,2,10,"litre",200),(1,3,1.2,"kg",200),(1,4,200,"piece",200),(1,5,10,"piece",200)]
        c.executemany("INSERT INTO bom VALUES(?,?,?,?,?)",bom)
        opening=[(1,100,"kg",4200),(2,30,"litre",14000),(3,5,"kg",20000),(4,500,"piece",250),(5,30,"piece",1500)]
        for mid,q,u,rate in opening: move(c,"material",mid,q,u,"OPENING","seed",0,rate)
        move(c,"product",1,50,"packet","OPENING","seed",0,0)
    c.commit(); c.close()

def move(c,typ,iid,qty,unit,movement,src,srcid,cost=0):
    c.execute("INSERT INTO ledger(item_type,item_id,qty,unit,movement,source_type,source_id,unit_cost_paise,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
      (typ,iid,qty,unit,movement,src,srcid,cost,datetime.now().isoformat(timespec="seconds")))

def balance(c,typ,iid):
    row=c.execute("SELECT COALESCE(SUM(qty),0) q FROM ledger WHERE item_type=? AND item_id=?",(typ,iid)).fetchone()
    return float(row["q"])

def current_avg(c,mid):
    rows=c.execute("SELECT qty,unit_cost_paise,movement FROM ledger WHERE item_type='material' AND item_id=? ORDER BY id",(mid,)).fetchall()
    q=Decimal(0); val=Decimal(0)
    for r in rows:
        qty=Decimal(str(r["qty"]))
        if r["movement"] in ("OPENING","PURCHASE"):
            q+=qty; val+=qty*Decimal(r["unit_cost_paise"])
        elif r["movement"] in ("PRODUCTION_ISSUE","DAMAGE","ADJUSTMENT"):
            if q>0:
                avg=val/q; val-=qty*avg; q-=qty
    return int((val/q).quantize(Decimal("1"),rounding=ROUND_HALF_UP)) if q>0 else 0

TOKENS={}
def auth(authorization: Optional[str]=Header(None)):
    if not authorization or not authorization.startswith("Bearer "): raise HTTPException(401,"Login required")
    u=TOKENS.get(authorization[7:])
    if not u: raise HTTPException(401,"Invalid session")
    return u
def roles(*allowed):
    def check(user=Depends(auth)):
        if user["role"] not in allowed: raise HTTPException(403,"Role not permitted")
        return user
    return check
class Login(BaseModel): username:str; password:str
class PurchaseIn(BaseModel): material_id:int=1; qty:float=60; rate:float=45
class RunIn(BaseModel): product_id:int=1; actual_output:int=188; oil_actual:float=10.5; damaged_pouches:int=6; cartons_used:int=9; labour:float=1200; utilities:float=600
class OrderIn(BaseModel): customer_id:int; qty:int; product_id:int=1
class PaymentIn(BaseModel): invoice_id:int; amount:float

@app.on_event("startup")
def startup(): init()

@app.get("/",response_class=HTMLResponse)
def home(): return open("static/index.html",encoding="utf8").read()

@app.post("/api/login")
def login(x:Login):
    c=db(); row=c.execute("SELECT * FROM users WHERE username=? AND password=?",(x.username,hashlib.sha256(x.password.encode()).hexdigest())).fetchone(); c.close()
    if not row: raise HTTPException(401,"Incorrect username or password")
    token=secrets.token_urlsafe(24); TOKENS[token]={"id":row["id"],"username":row["username"],"role":row["role"]}
    return {"token":token,"user":TOKENS[token]}

@app.get("/api/me")
def me(user=Depends(auth)): return user

@app.get("/api/masters")
def masters(user=Depends(auth)):
    c=db()
    out={"customers":[dict(x) for x in c.execute("SELECT * FROM customers")],
         "products":[dict(x) for x in c.execute("SELECT * FROM products")],
         "materials":[dict(x) for x in c.execute("SELECT * FROM materials")]}
    c.close(); return out

@app.get("/api/dashboard")
def dashboard(user=Depends(auth)):
    c=db()
    stock=balance(c,"product",1)
    raw=[{"name":r["name"],"qty":balance(c,"material",r["id"]),"unit":r["unit"]} for r in c.execute("SELECT * FROM materials")]
    orders=c.execute("SELECT COUNT(*) n FROM orders WHERE status IN ('SUBMITTED','SHORTAGE')").fetchone()["n"]
    inv=c.execute("SELECT COALESCE(SUM(total_paise),0) total FROM invoices WHERE status='POSTED'").fetchone()["total"]
    paid=c.execute("SELECT COALESCE(SUM(amount_paise),0) total FROM payments").fetchone()["total"]
    c.close()
    return {"finished_stock":stock,"pending_orders":orders,"invoiced":rupees(inv),"outstanding":rupees(inv-paid),"raw":raw}

@app.post("/api/purchase")
def purchase(x:PurchaseIn,user=Depends(roles("admin","production","owner"))):
    c=db(); mid=x.material_id; rate=money(x.rate)
    cur=c.execute("INSERT INTO purchases(material_id,qty,unit,rate_paise,created_at) VALUES(?,?,?,?,?)",(mid,x.qty,"kg",rate,datetime.now().isoformat()))
    pid=cur.lastrowid; move(c,"material",mid,x.qty,"kg","PURCHASE","purchase",pid,rate)
    c.execute("UPDATE materials SET rate_paise=? WHERE id=?",(rate,mid)); c.commit(); c.close()
    return {"purchase_id":pid,"new_balance":balance_read("material",mid)}

def balance_read(t,i):
    c=db(); v=balance(c,t,i); c.close(); return v

@app.post("/api/production/run")
def production(x:RunIn,user=Depends(roles("production","admin","owner"))):
    c=db()
    # Benchmark standard issue; actual oil is intentionally above BOM.
    bom=c.execute("SELECT b.*,m.name,m.rate_paise,m.unit FROM bom b JOIN materials m ON m.id=b.material_id WHERE b.product_id=?",(x.product_id,)).fetchall()
    expected=200
    cur=c.execute("INSERT INTO runs(product_id,expected_output,actual_output,wastage,labour_paise,utilities_paise,created_at) VALUES(?,?,?,?,?,?,?)",
      (x.product_id,expected,x.actual_output,x.damaged_pouches,money(x.labour),money(x.utilities),datetime.now().isoformat()))
    rid=cur.lastrowid
    actuals={1:40,2:x.oil_actual,3:1.2,4:x.actual_output+x.damaged_pouches,5:x.cartons_used}
    for b in bom:
        actual=actuals[b["material_id"]]; rate=current_avg(c,b["material_id"])
        if balance(c,"material",b["material_id"])+1e-9<actual: c.rollback(); c.close(); raise HTTPException(400,f"Insufficient {b['name']}")
        c.execute("INSERT INTO run_lines(run_id,material_id,planned,actual,unit,rate_paise,damaged) VALUES(?,?,?,?,?,?,?)",
          (rid,b["material_id"],b["qty"],actual,b["unit"],rate,x.damaged_pouches if b["material_id"]==4 else 0))
        move(c,"material",b["material_id"],-actual,b["unit"],"PRODUCTION_ISSUE","production_run",rid,rate)
    move(c,"product",x.product_id,x.actual_output,"packet","PRODUCTION_OUTPUT","production_run",rid,0)
    c.commit()
    lines=[dict(r) for r in c.execute("SELECT rl.*,m.name FROM run_lines rl JOIN materials m ON m.id=rl.material_id WHERE run_id=?",(rid,))]
    c.close()
    return {"run_id":rid,"expected_output":expected,"actual_output":x.actual_output,"yield_variance_pct":round((x.actual_output-expected)/expected*100,2),
      "lines":[{**r,"variance_pct":round((r["actual"]-r["planned"])/r["planned"]*100,2)} for r in lines],
      "flags":["Yield variance exceeds 3%" if x.actual_output<expected*.97 else "","Oil consumption variance exceeds 3%" if x.oil_actual>10.3 else ""]}

@app.post("/api/orders")
def create_order(x:OrderIn,user=Depends(roles("salesman","admin","owner"))):
    c=db()
    cur=c.execute("INSERT INTO orders(customer_id,salesman_id,status,created_at) VALUES(?,?,?,?)",(x.customer_id,user["id"],"SUBMITTED",datetime.now().isoformat()))
    oid=cur.lastrowid; c.execute("INSERT INTO order_lines(order_id,product_id,qty,price_paise) VALUES(?,?,?,?)",(oid,x.product_id,x.qty,5000))
    c.commit(); c.close(); return {"order_id":oid,"status":"SUBMITTED"}

@app.get("/api/orders")
def orders(user=Depends(auth)):
    c=db()
    sql="""SELECT o.id,o.status,o.shortage,o.created_at,cu.name customer,u.username salesman,
    p.name product,ol.qty,ol.price_paise FROM orders o JOIN customers cu ON cu.id=o.customer_id
    JOIN users u ON u.id=o.salesman_id JOIN order_lines ol ON ol.order_id=o.id JOIN products p ON p.id=ol.product_id"""
    if user["role"]=="salesman": sql+=" WHERE o.salesman_id="+str(user["id"])
    rows=[dict(r) for r in c.execute(sql+" ORDER BY o.id DESC")]
    c.close(); return rows

@app.post("/api/orders/{oid}/approve")
def approve(oid:int,user=Depends(roles("admin","owner"))):
    c=db(); o=c.execute("SELECT o.*,cu.state,ol.qty,ol.product_id,ol.price_paise FROM orders o JOIN customers cu ON cu.id=o.customer_id JOIN order_lines ol ON ol.order_id=o.id WHERE o.id=?",(oid,)).fetchone()
    if not o: c.close(); raise HTTPException(404,"Order not found")
    available=int(balance(c,"product",o["product_id"]))
    if available<o["qty"]:
        shortage=o["qty"]-available; c.execute("UPDATE orders SET status='SHORTAGE',shortage=? WHERE id=?",(shortage,oid)); c.commit(); c.close()
        return {"status":"SHORTAGE","available":available,"requested":o["qty"],"shortage":shortage}
    taxable=o["qty"]*o["price_paise"]; tax=int((Decimal(taxable)*Decimal("0.05")/2).quantize(Decimal("1"),rounding=ROUND_HALF_UP))
    intra=o["state"]=="Tamil Nadu"; cgst=tax if intra else 0; sgst=tax if intra else 0; igst=0 if intra else tax*2
    total=taxable+cgst+sgst+igst
    fy="26-27" if date.today().month>=4 else "25-26"
    count=c.execute("SELECT COUNT(*) n FROM invoices").fetchone()["n"]+1; no=f"SF/{fy}/{count:04d}"
    cur=c.execute("INSERT INTO invoices(order_id,invoice_no,taxable_paise,cgst_paise,sgst_paise,igst_paise,total_paise,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
      (oid,no,taxable,cgst,sgst,igst,total,"POSTED",datetime.now().isoformat()))
    iid=cur.lastrowid; c.execute("UPDATE orders SET status='INVOICED' WHERE id=?",(oid,)); c.commit(); c.close()
    return {"status":"INVOICED","invoice_id":iid,"invoice_no":no,"taxable":rupees(taxable),"cgst":rupees(cgst),"sgst":rupees(sgst),"igst":rupees(igst),"total":rupees(total)}

@app.post("/api/invoices/{iid}/dispatch")
def dispatch(iid:int,user=Depends(roles("admin","owner"))):
    c=db(); inv=c.execute("SELECT i.*,ol.qty,ol.product_id FROM invoices i JOIN order_lines ol ON ol.order_id=i.order_id WHERE i.id=?",(iid,)).fetchone()
    if not inv: c.close(); raise HTTPException(404,"Invoice not found")
    if c.execute("SELECT 1 FROM ledger WHERE source_type='dispatch' AND source_id=?",(iid,)).fetchone(): c.close(); raise HTTPException(400,"Already dispatched")
    if balance(c,"product",inv["product_id"])<inv["qty"]: c.close(); raise HTTPException(400,"Insufficient finished goods")
    move(c,"product",inv["product_id"],-inv["qty"],"packet","DISPATCH","dispatch",iid,0)
    c.execute("UPDATE orders SET status='DISPATCHED' WHERE id=?",(inv["order_id"],)); c.commit(); c.close()
    return {"status":"DISPATCHED","remaining_stock":balance_read("product",1)}

@app.post("/api/payments")
def payment(x:PaymentIn,user=Depends(roles("admin","owner"))):
    c=db(); cur=c.execute("INSERT INTO payments(invoice_id,amount_paise,received_at) VALUES(?,?,?)",(x.invoice_id,money(x.amount),datetime.now().isoformat()))
    c.commit(); c.close(); return {"payment_id":cur.lastrowid}

@app.get("/api/production")
def production_report(user=Depends(auth)):
    c=db(); runs=[]
    for r in c.execute("SELECT * FROM runs ORDER BY id DESC"):
        lines=[]
        for l in c.execute("SELECT rl.*,m.name FROM run_lines rl JOIN materials m ON m.id=rl.material_id WHERE run_id=?",(r["id"],)):
            lines.append({**dict(l),"variance_pct":round((l["actual"]-l["planned"])/l["planned"]*100,2)})
        runs.append({**dict(r),"yield_variance_pct":round((r["actual_output"]-r["expected_output"])/r["expected_output"]*100,2),"lines":lines})
    c.close(); return runs

@app.get("/api/stock")
def stock(user=Depends(auth)):
    c=db(); rows=[]
    for typ,table in [("material","materials"),("product","products")]:
        for r in c.execute(f"SELECT * FROM {table}"):
            iid=r["id"]; q=balance(c,typ,iid)
            rows.append({"type":typ,"id":iid,"name":r["name"],"unit":r["unit"] if typ=="material" else "packet","balance":q})
    c.close(); return rows

@app.get("/api/ledger")
def ledger(user=Depends(auth)):
    c=db(); rows=[dict(r) for r in c.execute("""SELECT l.*,CASE WHEN item_type='material' THEN m.name ELSE p.name END item
      FROM ledger l LEFT JOIN materials m ON l.item_type='material' AND m.id=l.item_id
      LEFT JOIN products p ON l.item_type='product' AND p.id=l.item_id ORDER BY l.id DESC""")]
    c.close(); return rows

@app.get("/api/reports/sales.csv")
def sales_csv(user=Depends(roles("admin","auditor","owner"))):
    c=db(); rows=c.execute("""SELECT i.invoice_no,cu.name customer,cu.state,o.status,i.taxable_paise,i.cgst_paise,i.sgst_paise,i.igst_paise,i.total_paise
    FROM invoices i JOIN orders o ON o.id=i.order_id JOIN customers cu ON cu.id=o.customer_id ORDER BY i.id""").fetchall(); c.close()
    s=io.StringIO(); w=csv.writer(s); w.writerow(["Invoice","Customer","State","Order status","Taxable ₹","CGST ₹","SGST ₹","IGST ₹","Total ₹"])
    for r in rows: w.writerow([r["invoice_no"],r["customer"],r["state"],r["status"],*[f"{rupees(r[k]):.2f}" for k in ("taxable_paise","cgst_paise","sgst_paise","igst_paise","total_paise")]])
    return StreamingResponse(iter([s.getvalue()]),media_type="text/csv",headers={"Content-Disposition":"attachment; filename=sales-register.csv"})

@app.get("/api/reports/stock.csv")
def stock_csv(user=Depends(roles("admin","auditor","owner","production"))):
    rows=stock(user); s=io.StringIO(); w=csv.writer(s); w.writerow(["Type","Item","Balance","Unit"])
    for r in rows: w.writerow([r["type"],r["name"],r["balance"],r["unit"]])
    return StreamingResponse(iter([s.getvalue()]),media_type="text/csv",headers={"Content-Disposition":"attachment; filename=stock-summary.csv"})

@app.get("/api/invoices/{iid}.pdf")
def invoice_pdf(iid:int,user=Depends(roles("admin","auditor","owner"))):
    c=db(); r=c.execute("""SELECT i.*,cu.name customer,cu.state,cu.gstin,p.name product,ol.qty,ol.price_paise
      FROM invoices i JOIN orders o ON o.id=i.order_id JOIN customers cu ON cu.id=o.customer_id
      JOIN order_lines ol ON ol.order_id=o.id JOIN products p ON p.id=ol.product_id WHERE i.id=?""",(iid,)).fetchone(); c.close()
    if not r: raise HTTPException(404,"Invoice not found")
    path=f"/tmp/smartfood-invoice-{iid}.pdf"; cv=canvas.Canvas(path,pagesize=A4)
    cv.setFont("Helvetica-Bold",18); cv.drawString(50,800,"SMARTFOOD — TAX INVOICE")
    cv.setFont("Helvetica",10); y=765
    for line in [f"Invoice: {r['invoice_no']}",f"Customer: {r['customer']} ({r['state']})",f"GSTIN (demo): {r['gstin']}",f"HSN: 1905",f"Product: {r['product']} | Qty: {r['qty']} | Rate: Rs {rupees(r['price_paise']):.2f}",f"Taxable: Rs {rupees(r['taxable_paise']):.2f}",f"CGST: Rs {rupees(r['cgst_paise']):.2f}",f"SGST: Rs {rupees(r['sgst_paise']):.2f}",f"IGST: Rs {rupees(r['igst_paise']):.2f}",f"TOTAL: Rs {rupees(r['total_paise']):.2f}"]:
        cv.drawString(50,y,line); y-=25
    cv.drawString(50,500,"Demo invoice only — verify GST registration and classification before real use.")
    cv.save(); return FileResponse(path,media_type="application/pdf",filename=f"{r['invoice_no'].replace('/','-')}.pdf")

@app.get("/api/costing")
def costing(user=Depends(auth)):
    c=db(); r=c.execute("SELECT * FROM runs ORDER BY id DESC LIMIT 1").fetchone()
    if not r: c.close(); return {"message":"No production run yet"}
    material_cost=0
    for l in c.execute("SELECT actual,rate_paise FROM run_lines WHERE run_id=?",(r["id"],)):
        material_cost+=money(Decimal(str(l["actual"]))*Decimal(l["rate_paise"])/100)
    total=material_cost+r["labour_paise"]+r["utilities_paise"]
    result={"material_cost":rupees(material_cost),"labour":rupees(r["labour_paise"]),"utilities":rupees(r["utilities_paise"]),
            "total_cost":rupees(total),"good_packets":r["actual_output"],"cost_per_packet":round(rupees(total)/r["actual_output"],2)}
    c.close(); return result

init()
